package com.byagowi.persiancalendar.ui

import androidx.appcompat.widget.Toolbar

interface DrawerHost {
    fun setupToolbarWithDrawer(toolbar: Toolbar)
}
