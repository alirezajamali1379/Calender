package com.byagowi.persiancalendar.variants

@Suppress("UNUSED_PARAMETER")
fun debugLog(message: String) = Unit // Nothing here

@Suppress("UNUSED_PARAMETER")
inline val <T> T.debugAssertNotNull: T
    inline get() = this // Nothing here
