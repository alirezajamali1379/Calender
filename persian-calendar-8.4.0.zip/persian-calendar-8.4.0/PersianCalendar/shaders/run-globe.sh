#!/bin/bash

glslViewer globe.frag map.png
